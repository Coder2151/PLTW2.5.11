import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class NimGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        System.out.println("Welcome to the Nim Game!");

        do {
            // Initialize game
            String player1 = getPlayerName(scanner, 1);
            String player2 = getPlayerName(scanner, 2);
            int pileSize = random.nextInt(41) + 10; // Random pile size between 10 and 50
            int currentPlayer = random.nextInt(2) + 1; // Randomly choose the starting player

            System.out.println("\nGame started!");
            System.out.println(player1 + " vs " + player2);
            System.out.println("Initial pile size: " + pileSize);

            // Game loop
            while (pileSize > 1) {
                int piecesToRemove = getPlayerMove(scanner, currentPlayer, pileSize);
                pileSize -= piecesToRemove;
                System.out.println(currentPlayer == 1 ? player1 : player2 + " removed " + piecesToRemove + " pieces.");
                System.out.println("Current pile size: " + pileSize);
                currentPlayer = 3 - currentPlayer; // Switch player (1 <-> 2)
            }

            // Announce winner
            System.out.println("\nGame over!");
            int winner = currentPlayer;
            System.out.println("Congratulations, " + (winner == 1 ? player1 : player2) + "! You won!");

        } while (playAgain(scanner));

        System.out.println("Thanks for playing!");
    }

    private static String getPlayerName(Scanner scanner, int playerNumber) {
        System.out.print("Enter the name for Player " + playerNumber + ": ");
        return scanner.nextLine();
    }

    private static int getPlayerMove(Scanner scanner, int currentPlayer, int pileSize) {
        int maxPieces = Math.min(pileSize / 2, pileSize);
        int piecesToRemove = 0;

        while (true) {
            try {
                System.out.print("Player " + currentPlayer + ", enter the number of pieces to remove (1-" + maxPieces + "): ");
                piecesToRemove = scanner.nextInt();

                if (piecesToRemove < 1 || piecesToRemove > maxPieces) {
                    System.out.println("Invalid input. Enter a number between 1 and " + maxPieces + ".");
                } else {
                    break; // Valid input, exit the loop
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.nextLine(); // Clear the invalid input from the scanner
            }
        }

        scanner.nextLine(); // Consume the newline character
        return piecesToRemove;
    }

    private static boolean playAgain(Scanner scanner) {
        System.out.print("Do you want to play again? (yes/no): ");
        String response = scanner.nextLine().toLowerCase();
        return response.equals("yes");
    }
}


